<?php
$telegram_id = "5785871015";
$token_bot = "7304944558:AAFcWsFhJoauzjfh3sj9C_fkHZCAoZusiZc";
?>
